//
//  CameraCollectionViewCell.h
//  PhotoLibraryDemo
//
//  Created by 张齐朴 on 16/5/20.
//  Copyright © 2016年 张齐朴. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CameraCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgV;

@end
