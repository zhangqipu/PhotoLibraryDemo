//
//  CameraCollectionViewCell.m
//  PhotoLibraryDemo
//
//  Created by 张齐朴 on 16/5/20.
//  Copyright © 2016年 张齐朴. All rights reserved.
//

#import "CameraCollectionViewCell.h"

@implementation CameraCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
